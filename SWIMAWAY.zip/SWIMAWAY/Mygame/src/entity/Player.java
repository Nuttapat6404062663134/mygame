package entity;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import Main.GamePanel;
import Main.KeyHandler;

public class Player extends Entity {

	KeyHandler keyH;
	public final int screenX;
	public final int screenY;

	public Player(GamePanel gp, KeyHandler keyH) {

		super(gp); // abstract
		this.keyH = keyH;

		screenX = gp.screenWidth / 2 - (gp.tileSize / 2);
		screenY = gp.screenHeight / 2 - (gp.tileSize / 2);

		solidArea = new Rectangle();
		solidArea.x = 20; // 20
		solidArea.y = 50;
		solidAreaDefaultX = solidArea.x;
		solidAreaDefaultY = solidArea.y;
		solidArea.width = 20;
		solidArea.height = 20;

		setDefaultValues();
		getPlayerImage();
	}

	public void setDefaultValues() {

		worldX = gp.tileSize * 8;
		worldY = gp.tileSize * 143;
		speed = 10; // 7
		direction = "up";

		// PLAYER STATUS
		maxLife = 10;
		life = maxLife;
	}

	public void getPlayerImage() {

		try {

			diver = ImageIO.read(getClass().getResourceAsStream("/player/diver.png"));
			baddy = ImageIO.read(getClass().getResourceAsStream("/player/bads.png"));
			goody = ImageIO.read(getClass().getResourceAsStream("/player/goods.png"));

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void update() {

		if (keyH.upPressed == true) {
			direction = "up";
		} else if (keyH.downPressed == true) {
			direction = "down";
		}
		if (keyH.leftPressed == true) {
			direction = "left";
		} else if (keyH.rightPressed == true) {
			direction = "right";
		}

		// Check tile collision
		collisionOn = false;
		gp.cChecker.checkTile(this);

		// check obj collision
		int objIndex = gp.cChecker.checkObject(this, true);
		pickupobj(objIndex);

		// check event
		gp.eHandler.checkEvent();
		// gp.eHandler.checkevent2(); // edit

		// If collision is false , player can move
		if (collisionOn == false) {
			switch (direction) {
				case "up":
					worldY = worldY - speed;
					break;
				case "down":
					worldY = worldY + speed;
					break;
				case "left":
					worldX = worldX - speed;
					break;
				case "right":
					worldX = worldX + speed;
					break;
			}
		}
		if (life <= 0) {
			gp.gameState = gp.gameOverState;
		}
	}

	public void pickupobj(int i) {

		if (i != 999) {

			gp.obj[i] = null;
			gp.ui.gameFinished = true;
		}

	}

	public void collision(int i) {
		// System.out.println(gp.obj[i]);
	}

	public void draw(Graphics2D g2) {

		g2.setColor(Color.white);
		// g2.fillRect(x, y, gp.tileSize, gp.tileSize);

		BufferedImage image = diver;

		g2.drawImage(image, screenX, screenY, gp.tileSize, gp.tileSize, null);
		// g2.setColor(Color.RED);
		// g2.fillRect(screenX, screenY, solidArea.x, solidArea.y);
	}

}

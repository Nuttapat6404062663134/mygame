package Main;

import java.awt.Rectangle;
import java.awt.Graphics2D;
import java.awt.Color;

public class EventHandler {

	GamePanel gp;
	Rectangle eventRect;
	int eventRectDefaultX, eventRectDefaultY;
	private boolean damagePitTriggered = false;
	private boolean healTriggered = false;

	public EventHandler(GamePanel gp) {
		this.gp = gp;

		eventRect = new Rectangle();
		eventRect.x = 5;
		eventRect.y = 5;
		eventRect.width = 10;
		eventRect.height = 10;
		eventRectDefaultX = eventRect.x;
		eventRectDefaultY = eventRect.y;
	}

	public void checkEvent() {

		if (hit(13, 5) || hit(14, 5)) {
			damagePit();
		} else if (hit(1, 8) || hit(5, 8)) {
			damagePit();
		} else if (hit(7, 13) || hit(10, 13)) {
			damagePit();
		} else if (hit(1, 22) || hit(4, 22)) {
			damagePit();
		} else if (hit(12, 28) || hit(15, 28)) {
			damagePit();
		} else if (hit(7, 35) || hit(9, 35)) {
			damagePit();
		} else if (hit(1, 43) || hit(4, 43)) {
			damagePit();
		} else if (hit(12, 48) || hit(15, 48)) {
			damagePit();
		} else if (hit(7, 54) || hit(10, 54)) {
			damagePit();
		} else if (hit(12, 63) || hit(15, 63)) {
			damagePit();
		} else if (hit(1, 69) || hit(4, 69)) {
			damagePit();
		} else if (hit(7, 75) || hit(10, 75)) {
			damagePit();
		} else if (hit(1, 83) || hit(4, 83)) {
			damagePit();
		} else if (hit(13, 85) || hit(14, 85)) {
			damagePit();
		} else if (hit(7, 92) || hit(10, 92)) {
			damagePit();
		} else if (hit(1, 96) || hit(4, 96)) {
			damagePit();
		} else if (hit(1, 103) || hit(4, 103)) {
			damagePit();
		} else if (hit(12, 106) || hit(15, 106)) {
			damagePit();
		} else if (hit(8, 113) || hit(9, 113)) {
			damagePit();
		} else if (hit(12, 117) || hit(15, 117)) {
			damagePit();
		} else if (hit(7, 120) || hit(10, 120)) {
			damagePit();
		} else if (hit(4, 124) || hit(5, 124)) {
			damagePit();
		} else if (hit(7, 128) || hit(10, 128)) {
			damagePit();
		} else if (hit(7, 137) || hit(10, 137)) {
			damagePit();
		} else if (hit(1, 142) || hit(4, 142)) {
			damagePit();

		} else if (hit(13, 18)) {
			heal();
		} else if (hit(5, 30)) {
			heal();
		} else if (hit(4, 59)) {
			heal();
		} else if (hit(14, 79)) {
			heal();
		} else if (hit(4, 88)) {
			heal();
		} else if (hit(14, 99)) {
			heal();
		} else if (hit(8, 110)) {
			heal();
		} else if (hit(4, 117)) {
			heal();
		} else if (hit(14, 132)) {
			heal();
		}
	}

	public boolean hit(int eventCol, int eventRow) {

		boolean hit = false;
		gp.player.solidArea.x = gp.player.worldX + gp.player.solidArea.x;
		gp.player.solidArea.y = gp.player.worldY + gp.player.solidArea.y;
		eventRect.x = eventCol * gp.tileSize + eventRect.x;
		eventRect.y = eventRow * gp.tileSize + eventRect.y;
		if (gp.player.solidArea.intersects(eventRect)) {

			System.out.println(eventRect);
			hit = true;
		}

		gp.player.solidArea.x = gp.player.solidAreaDefaultX;
		gp.player.solidArea.y = gp.player.solidAreaDefaultY;
		eventRect.x = eventRectDefaultX;
		eventRect.y = eventRectDefaultY;

		return hit;
	}

	public void damagePit() {

		gp.ui.showMessage("YOU GOT BITE");
		gp.player.life -= 1;
		gp.player.speed -= 1;

	}

	public void heal() {

		gp.ui.showMessage("Healed");
		gp.player.speed += 1;
		if (gp.player.life > gp.player.maxLife) {
			gp.player.life += 1;

		} else {
			gp.player.life = gp.player.maxLife;

		}

	}

}

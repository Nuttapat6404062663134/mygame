package Object;

import java.awt.image.BufferedImage;

import java.io.IOException;

import javax.imageio.ImageIO;
import Main.GamePanel;

public class OBJ_Key extends SuperObject{
	
	GamePanel gp;
	
	public OBJ_Key(GamePanel gp) {
		
		name ="key";
		try {
			
		BufferedImage circle = ImageIO.read(getClass().getResourceAsStream("/objects/circle.png"));
		
		}catch(IOException e) {
			e.printStackTrace();
		}
		collision = true;
	}
}
